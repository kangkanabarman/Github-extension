const supportedLabels = /^(?:bug|bug-?fix|confirmed-bug|(?:category|type|kind|triage|issue)[:/-]bug|(?::[\w-]+:|\p{Emoji})bug)$/iu;
export default function isBugLabel(label: string): boolean {
	return supportedLabels.test(label.replaceAll(/\s/g, ''));
}
