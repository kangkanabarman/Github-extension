import './scrollable-areas.css';

import features from '../feature-manager.js';

void features.addCssFeature(import.meta.url);

/*

Test URLs:

https://github.com/refined-github/refined-github/pull/1146#issuecomment-377296024

*/
