/** @type {import('rollup-plugin-svelte').Options} */
export default {
	compilerOptions: {
		// Compile all components to custom elements
		customElement: true,
	},
};
